﻿#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cmath>
#include <regex>
#include <sstream>
#include <chrono>
#include <ctime>
#include <omp.h>
#include <nlohmann/json.hpp> //POZOR to knjižnico je potrebno ločeno naložiti iz githuba (https://github.com/nlohmann/json) in shraniti v folder projekta
//paziti moramo tudi, da dodamo pot do dodatne knjižnice v properties našega projekta

using json = nlohmann::json;

std::vector<std::vector<double>> tocke; // vektor točk
std::vector<std::vector<double>> celice; // vektor celic
std::vector<double> T; // vektor vrednosti T po vozliščih

std::vector<std::string> vrsteRP;
std::string vrsta_RP;
std::vector<double> vrednostiRP;
std::vector<std::vector<int>> tockeRP;
std::vector<int> velikosti;
std::vector<int> vrednosti_prestopa;

int deltaX = 1;
int deltaY = 1;
int k = 1;



void PreberiTocke(std::string filename) {

    std::ifstream indata;
    indata.open(filename);



    int zaporedna;
    std::string text;
    double a, b, c, d;
    char semicolon, colon;

    //TOČKE

    //preberemo št. točk


    std::string vrstica;
    std::getline(indata, vrstica);
    std::stringstream tt(vrstica);

    tt >> text >> a;
    velikosti.push_back(a);

    tt.clear();

    std::cout << "Stevilo tock: " << velikosti[0] << "\n";

    //gremo čez vse točke, shranmo v vektor
    for (int i = 0; i < velikosti[0]; i++) {

        std::string line;
        std::getline(indata, line);
        std::stringstream ss(line);

        ss >> zaporedna >> semicolon >> a >> colon >> b;

        tocke.push_back({ a, b });

    }

    // Print Tock
    for (int i = 0; i < velikosti[0]; i++) {


    }

    //CELICE

    //preberemo št. celic
    std::getline(indata, vrstica);
    std::getline(indata, vrstica);

    std::stringstream cc(vrstica);

    cc >> text >> a;
    velikosti.push_back(a);

    cc.clear();

    std::cout << "Stevilo celic: " << velikosti[1] << std::endl;

    //gremo čez vse celice
    for (int i = 0; i < velikosti[1]; i++) {

        std::string line;
        std::getline(indata, line);
        std::stringstream ss(line);

        ss >> zaporedna >> semicolon >> a >> colon >> b >> colon >> c >> colon >> d;

        celice.push_back({ a, b ,c ,d });
    }

    //ROBNI POGOJI

    //preberemo št. robnih pogojev

    std::getline(indata, vrstica);
    std::getline(indata, vrstica);

    std::stringstream rp(vrstica);

    rp >> text >> text >> a;
    velikosti.push_back(a);

    cc.clear();

    std::cout << "Stevilo robnih pogojev: " << velikosti[2] << std::endl;

    //Gremo čez vse robne pogoje

    std::string uporabntext;
    int vemodajeprestop = 0;

    for (int i = 0; i < velikosti[2]; i++) {

        int stTock;
        std::string stevilka = "";
        std::vector<int> trenutneTocke = {};

        //vrsta RP

        std::getline(indata, vrstica);
        for (int ii = 0; ii < vrstica.length(); ii++) {
            stevilka += vrstica[ii];

            if (vrstica[ii] == ' ') {
                stevilka = "";
            }
            else if (ii == vrstica.length() - 1) {//////////////////////////////////////
                std::string vrsta_RP = "";
                vrsta_RP = stevilka;
                vrsteRP.push_back(vrsta_RP);
                if (vrsta_RP == "prestop") {
                    vemodajeprestop = 1;
                }
                else {
                    vemodajeprestop = 0;
                }
                stevilka = "";
            }

        }

        //vrednost RP
        std::getline(indata, vrstica);

        for (int ii = 0; ii < vrstica.length(); ii++) {
            stevilka += vrstica[ii];

            if (vrstica[ii] == ' ') {
                stevilka = "";
            }
            else if (ii == vrstica.length() - 1) {
                int st;
                if (vemodajeprestop == 1) {
                    st = std::stoi(stevilka);
                    vrednostiRP.push_back(st);



                    std::getline(indata, vrstica);



                    size_t colonPos = vrstica.find(':');
                    size_t spacePos = vrstica.find(' ', colonPos);

                    int stevilo;
                    std::istringstream iss(vrstica.substr(spacePos + 1));
                    iss >> stevilo;


                    stevilka = "";
                    vrednosti_prestopa.push_back(stevilo);
                    break;
                }
                else {
                    vrednosti_prestopa.push_back(-1);
                    int st;
                    st = std::stoi(stevilka);
                    vrednostiRP.push_back(st);

                    stevilka = "";
                }

            }
        }
        for (int ii = 0; ii < velikosti[2]; ii++) {
        }



        //gremo čez vse točke RP

        //št. točk

        std::getline(indata, vrstica);
        std::stringstream st(vrstica);

        st >> stTock;

        for (int i = 0; i < stTock; i++) {

            std::string line;
            std::getline(indata, line);
            std::stringstream ss(line);

            ss >> a;

            trenutneTocke.push_back(a);
        }
        tockeRP.push_back(trenutneTocke);

        std::getline(indata, vrstica);

    }


}


void SestaviMatrike(std::vector<double>& B, std::vector<std::vector<double>>& A) {


    //preoblikujemo matriko A in vektor b
    int rows = velikosti[0];
    A.resize(rows, std::vector<double>(rows, 0));
    B.resize(rows, 0);





    //ustvarimo vektor v katero bomo shranili sosede trenutno obravnavane točke
    std::vector<double>node_i_neighbours = { -1, -1, -1, -1 };

    //ustvarimo matriko kamor bomo shranili sosednja vozlišča, da bomo imeli zbirko vseh sosedov za vsako vozlišče
    std::vector<std::vector<double>>sosednja_vozlisca;

    //levi sosed, prvi element
    //spodnji sosed, drugi element
    //desni sosed, tretji element
    //zgornji sosed, četrti element

    int pozicija = 0;

    //node_id predstavlja številko trenutnega vozlišča
    for (int node_id = 0; node_id < velikosti[0]; node_id++) {
        node_i_neighbours = { -1, -1, -1, -1 };
        for (int nd = 0; nd < velikosti[1]; nd++) {
            std::vector<double> trenutna_celica = celice[nd];

            //preverjamo ali se naše trenutno vozlišče nahaja v celici, če se, morata biti dve izmed treh ostalih vozlišč 
            //zgoraj, spodaj, levo ali desno od našega trenutnega vozlišča. 
            int vozlisce1 = trenutna_celica[0];
            int vozlisce2 = trenutna_celica[1];
            int vozlisce3 = trenutna_celica[2];
            int vozlisce4 = trenutna_celica[3];

            if (node_id == vozlisce1 || node_id == vozlisce2 || node_id == vozlisce3 || node_id == vozlisce4) {
                for (int vozl = 0; vozl < 4; vozl++) {
                    //naredimo iteracijo po trenutni celici in za vsako vozlišče preverimo ali je naše trenutno vozlišče
                    //ali sosed trenutnega vozlišča
                    int sosednje_vozlisce = trenutna_celica[vozl];
                    if (sosednje_vozlisce != node_id) {
                        double x_obravnavano_vozl = tocke[node_id][0];
                        double y_obravnavano_vozl = tocke[node_id][1];
                        double x_sosed = tocke[sosednje_vozlisce][0];
                        double y_sosed = tocke[sosednje_vozlisce][1];
                        //v kolikor je vozlišče sosednje, moramo preveriti ali se nahaja zgoraj, spodaj, levo ali desno od 
                        //izbranega vozlišča
                        if ((x_obravnavano_vozl - x_sosed) < 1e-9 && (x_obravnavano_vozl - x_sosed) > -1e-9) {
                            //sosednje vozlišče se nahaja vertikalno, preverimo ali je to zgoraj ali spodaj
                            if ((y_obravnavano_vozl - y_sosed) > 0) {
                                pozicija = 1;
                                //nahaja se spodaj
                            }
                            else {
                                pozicija = 3;
                                //nahaja se zgoraj
                            }
                        }
                        else if ((y_obravnavano_vozl - y_sosed) < 1e-9 && (y_obravnavano_vozl - y_sosed) > -1e-9) {
                            if ((x_obravnavano_vozl - x_sosed) > 0) {
                                //sosenje vozlišče se nahaja horizontalno
                                pozicija = 0;
                                //nahaja se levo
                            }
                            else {
                                pozicija = 2;
                                //nahaja se desno
                            }
                        }

                        else {
                            //če vozlišči nista poravnani horizontalno ali vertikalno, ne storimo ničesar
                            pozicija = -1;
                        }

                        //v kolikor ena izmed vrednosti ni -1, torej je 0,1,2,3
                        if (pozicija != -1) {
                            node_i_neighbours[pozicija] = sosednje_vozlisce;

                        }

                    }
                }
            }

        }
        //vektor trenutnih sosedov dodamo v vektor vseh sosedov
        sosednja_vozlisca.push_back(node_i_neighbours);

    }



    //sedaj ko imamo matriko vseh sosednov lahko iteriramo po vozliščih in zapišemo člene v matriko A.

    //iteriramo po vrsticah
    for (int node_id = 0; node_id < velikosti[0]; node_id++) {
        //izpišemo vse sosede, ki jih ima vozlišče node_id
        std::vector<double> sosedi = sosednja_vozlisca[node_id];
        int levi_sosed = sosedi[0];
        int spodnji_sosed = sosedi[1];
        int desni_sosed = sosedi[2];
        int zgornji_sosed = sosedi[3];



        std::string tip_robnega_pogoja;
        double vrednost;
        double vrednost_prestopa;


        //sedaj moramo ugotoviti, ali se vozlišče nahaja na robu in če se, kakšen je njegov robni pogoj.
        //v kolikor nobena izmed vrednosti ni -1, vozlišče ni na robu
        if (levi_sosed != -1 && desni_sosed != -1 && spodnji_sosed != -1 && zgornji_sosed != -1) {
            //sedaj vemo, da nismo na robu, zato uporabimo enačbo (12) iz predloge
            A[node_id][levi_sosed] = 1;
            A[node_id][spodnji_sosed] = 1;
            A[node_id][desni_sosed] = 1;
            A[node_id][zgornji_sosed] = 1;
            A[node_id][node_id] = -4;
            
        }
        else {

            //če ima eno izmed vozlišč vrednost -1 vemo, da smo na robu. Sedaj moramo ugotoviti kakšna vrsta roba je in kakšen
            //je robni pogoj
            for (int robni_pogoj_id = 0; robni_pogoj_id < velikosti[2]; robni_pogoj_id++) {
                std::vector<int> vozlisca_v_trenutnem_rp = tockeRP[robni_pogoj_id];

                for (int id_vozlisce_rp = 0; id_vozlisce_rp < vozlisca_v_trenutnem_rp.size(); id_vozlisce_rp++) {
                    int vozlisce_v_trenutnem_rp = vozlisca_v_trenutnem_rp[id_vozlisce_rp];
                    if (node_id == vozlisce_v_trenutnem_rp) {
                        //če je izbrano vozlišče v skupini vozlišč, ki pripadajo robnemu pogoju, izpišemo parametre za ta RP
                        tip_robnega_pogoja = vrsteRP[robni_pogoj_id];
                        //vrsta robnega pogoja je lahko temperatura, toplotni tok ali prestop toplote

                        vrednost = vrednostiRP[robni_pogoj_id];
                        //shrani vrednost temperature, toplotnega toka ali prenosa toplote

                        vrednost_prestopa = vrednosti_prestopa[robni_pogoj_id];
                        //vrednost je -1, če je tip robnega pogoja temperatura ali toplotni tok, drugače pa je
                        //koeficient prestopa toplote

                    }


                }
            }
            if (tip_robnega_pogoja == "temperatura") {

                //v tem primeru vemo temperaturo na robu, tu ni važno koliko sosedov ima naše vozlišče.
                A[node_id][node_id] = 1;

                
                B[node_id] = vrednost;
            }
            else if (tip_robnega_pogoja == "tok") {
                //gre za toplotni tok, tu je pommebno, koliko sosedov ima naše vozlišče in kje so te sosedi (levo, desno,...)
                //zato najprej izračunamo koliko sosedov ima vozlišče
                int st_sosedov = 0;
                for (int st = 0; st < 4; st++) {
                    if (sosedi[st] != -1) {
                        st_sosedov += 1;
                    }
                }
                //sedaj lahko na podlagi števila sosedov določimo enačbe
                if (st_sosedov == 3) {
                    if (levi_sosed == -1) {
                        //če levo od obravnavanega vozlišča ni soseda, to pomeni, da je vozlišče na levem robu, 
                        //uporabimo sledečo enačbo
                        A[node_id][node_id] += -4;
                        ;
                        
                        A[node_id][desni_sosed] += 2;
                        A[node_id][spodnji_sosed] += 1;
                        A[node_id][zgornji_sosed] += 1;
                        B[node_id] = -2 * (vrednost * deltaX / k);

                    }
                    if (desni_sosed == -1) {
                        //vozlišče je na desnem robu
                        A[node_id][node_id] += -4;

                        
                        A[node_id][levi_sosed] += 2;
                        A[node_id][spodnji_sosed] += 1;
                        A[node_id][zgornji_sosed] += 1;
                        B[node_id] = -2 * (vrednost * deltaX / k);
                    }
                    if (spodnji_sosed == -1) {
                        //vozlišče je na spodnjem robu
                        A[node_id][node_id] += -4;

                        
                        A[node_id][zgornji_sosed] += 2;
                        A[node_id][levi_sosed] += 1;
                        A[node_id][desni_sosed] += 1;
                        B[node_id] = -2 * (vrednost * deltaX / k);
                    }
                    if (zgornji_sosed == -1) {
                        //vozlišče je na zgornjem robu
                        A[node_id][node_id] += -4;

                        
                        A[node_id][spodnji_sosed] += 2;
                        A[node_id][levi_sosed] += 1;
                        A[node_id][desni_sosed] += 1;
                        B[node_id] = -2 * (vrednost * deltaX / k);
                    }
                }
            }
            else if (tip_robnega_pogoja == "prestop") {
                //tudi tu, ko imamo na robu prestop toplote, je pomembno število sosedov našega vozlišča in kateri so(levo, desno,...).
                int st_sosedov = 0;
                for (int st = 0; st < 4; st++) {
                    if (sosedi[st] != -1) {
                        st_sosedov += 1;
                    }
                }
                //sedaj lahko na podlagi števila sosedov nastavimo enačbe
                if (st_sosedov == 3) {
                    //preverimo kateri sosed manjka in zapišemo enačbo

                    if (levi_sosed == -1) {
                        //če levo od obravnavanega vozlišča ni soseda, to pomeni, da je vozlišče na levem robu, 
                        //uporabimo sledečo enačbo
                        A[node_id][node_id] += -2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][desni_sosed] += 2;
                        A[node_id][spodnji_sosed] += 1;
                        A[node_id][zgornji_sosed] += 1;
                        B[node_id] += -2 * vrednost_prestopa * deltaX * vrednost / k;
                    }

                    if (desni_sosed == -1) {
                        //vozlišče je na desnem robu
                        A[node_id][node_id] += -2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][levi_sosed] += 2;
                        A[node_id][spodnji_sosed] += 1;
                        A[node_id][zgornji_sosed] += 1;
                        B[node_id] += -2 * vrednost_prestopa * deltaX * vrednost / k;
                    }

                    if (spodnji_sosed == -1) {
                        //vozlišče je na spodnjem robu
                        A[node_id][node_id] += -2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][levi_sosed] += 1;
                        A[node_id][desni_sosed] += 1;
                        A[node_id][zgornji_sosed] += 2;
                        B[node_id] += -2 * vrednost_prestopa * deltaX * vrednost / k;
                    }

                    if (zgornji_sosed == -1) {
                        //vozlišče je na zgornjem robu
                        A[node_id][node_id] += -2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][levi_sosed] += 1;
                        A[node_id][desni_sosed] += 1;
                        A[node_id][spodnji_sosed] += 2;
                        B[node_id] += -2 * vrednost_prestopa * deltaX * vrednost / k;
                    }

                }

            }



        }
    }
    //Sedaj imamo sestavljeni matriki A in b. Lahko se lotimo reševanja sistema enačb po metodi Gauss-Seidel
}

void ResevanjeMatrik(const std::vector<double>& B, const std::vector<std::vector<double>>& A) {
    // Najprej inicializiramo vektor resitve T, npr. na 100 stopinj.

    for (int iiT = 0; iiT < velikosti[0]; iiT++)
    {
        T.push_back(100);
    }

    omp_set_num_threads(4);//tu lahko spremenimo število niti, ki rešujejo for zanko
    int n = velikosti[0];
    double d = 0;

#pragma omp parallel shared(A,B,T,n) private(d)
    {
        for (int iitt = 0; iitt < 1000; iitt++)
        {
#pragma omp for
            for (int jj = 0; jj < n; jj++) {
                d = B[jj];



                for (int ii = 0; ii < n; ii++) {
                    if (jj != ii) {
                        d = d - A[jj][ii] * T[ii];

                    }
                }
                T[jj] = d / A[jj][jj];
                if (A[jj][jj] == 0) {

                }
            }
        }
    }

    for (int ii = 0; ii < velikosti[0]; ii++) {

        std::cout << T[ii] << std::endl;
    }



}



int main() {
    auto start_time = std::chrono::high_resolution_clock::now();

    std::vector<double> mojB;
    std::vector<std::vector<double>> mojA;
    PreberiTocke("C:/Users/matij/Downloads/projekt_mreze/primer3mreza.txt");
    SestaviMatrike(mojB, mojA);
    ResevanjeMatrik(mojB, mojA);

    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_duration = end_time - start_time;
    std::cout << "Time  of Gauss-Seidel: " << time_duration.count() << " seconds" << std::endl;
    std::cout << T[19] << std::endl;

    //zapišimo rezultate v .txt datoteko 
    std::ofstream outputFile("rezultati_gauss_seidel.txt");
    for(int ii= 0; ii<velikosti[0]; ii++){
    outputFile << T[ii] << std::endl;
    }
    outputFile.close();




    //Sledi vizualizacija rezultatov
    std::vector<int> tockex;
    std::vector<int> tockey;

    for (int ii = 0; ii < velikosti[0]; ii++) {
        int x = tocke[ii][0];
        int y = tocke[ii][1];
        tockex.push_back(x);
        tockey.push_back(y);
    }

    int N_points = velikosti[0]; //število vozlišč
    int N_cells = velikosti[1]; //število celic
    std::vector<double> T_nodes = T; //vrednosti T po vozliščih
    std::vector<int>A_cells(velikosti[1], 1);

    std::ofstream out("output_vtk.vtk");//naslov output datoteke

    out << "# vtk DataFile Version 3.0\n";
    out << "MKE racunanje temperature \n";
    out << "ASCII\n";
    out << "DATASET UNSTRUCTURED_GRID\n";

    out << "POINTS " << N_points << " float\n";

    for (int i = 0; i < N_points; i++)//določimo vektorja x in y koordinat vozlišč
    {
        out << tockex[i] << " " << tockey[i] << " 0" << '\n';
    }

    out << "\n";

    //pri celicah je vrstica v obliki za pravokotnike "CELLS N N*5", kjer je N število celic
    out << "CELLS " << N_cells << " " << N_cells * 5 << "\n";

    for (int i_cell = 0; i_cell < N_cells; i_cell++)
    {
        //iteriramo po celicah, vsaka ima 4 vozlišča, zapišemo številke teh vozlišč  
        out << "4" << " " << celice[i_cell][0] << " " << celice[i_cell][1] << " " <<
            celice[i_cell][2] << " " << celice[i_cell][3] << '\n';
    }

    out << "\n";

    //za vsako celico zapišemo tip celice
    out << "CELL_TYPES " << N_cells << "\n";
    for (int i_cell = 0; i_cell < N_cells; i_cell++)
    {
        // pravokotnik je definiran s stevilko 9,
        out << "9" << '\n';
    }

    out << "\n";

    // Da definiramo vrednosti za vizualizacijo na vozliscih moramo uporabiti kljucno besedo "POINT_DATA"
    out << "POINT_DATA " << N_points << "\n";
    out << "SCALARS T float 1\n";
    out << "LOOKUP_TABLE default\n";

    // nato naredimo iteracijo po vektorju, kjer imamo vrednosti za vizualizacijo in jih zapisemo
    for (int i_point = 0; i_point < N_points; i_point++) out << T_nodes[i_point] << '\n';


    //podobno kot za vozlišča naredimo še za celice

    out << "CELL_DATA " << N_cells << "\n";
    out << "SCALARS A float 1\n";
    out << "LOOKUP_TABLE default\n";

    // nato naredimo iteracijo po vektorju, kjer imamo vrednosti za vizualizacijo in jih zapisemo
    for (int i_cell = 0; i_cell < N_cells; i_cell++) out << A_cells[i_cell] << '\n';

    // Na koncu zapremo datoteko. Lahko jo uvozimo v ParaView za vizualizacijo.
    out.close();


    //importanje matrike A in vektorja b v Wolfram Mathematico


    // ustvarimo objekt JSON
    json jsonData;
    jsonData["Array"] = mojA;
    jsonData["Vector"] = mojB;

    // Zapišemo podatke v JSON datoteko
    std::ofstream outputFile("output1.json");
    outputFile << std::setw(4) << jsonData << std::endl;
    outputFile.close();
    std::cout << "JSON data written to output.json" << std::endl;

    return 0;
}